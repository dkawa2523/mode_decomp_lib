from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any


class RunError(ValueError):
    """A failed run with useful output that should still be reported."""

    def __init__(self, message: str, result: RunResult) -> None:
        super().__init__(message)
        self.result = result


@dataclass
class RunResult:
    """Standard result object returned from package code.

    Package code returns this object. Runtime adapters decide whether to print it locally,
    upload it to ClearML, or inspect it in tests.
    """

    run_dir: Path
    metrics: dict[str, float] = field(default_factory=dict)
    artifacts: dict[str, Path] = field(default_factory=dict)
    tables: dict[str, Path] = field(default_factory=dict)
    plots: dict[str, Path] = field(default_factory=dict)
    extra: dict[str, Any] = field(default_factory=dict)
