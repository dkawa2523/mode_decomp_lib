"""ClearML-free primitives shared by ML platform packages."""
