"""Transport-neutral configuration syntax shared by business packages."""

from __future__ import annotations

from collections.abc import Mapping
from typing import Any

from .stages import as_stage_name


class ConfigValidationError(ValueError):
    """A public configuration value has an invalid common type."""


def validate_run_config(config: Mapping[str, Any]) -> None:
    """Check common syntax; business policy and stage membership are local."""
    if not isinstance(config, Mapping):
        raise ConfigValidationError("run config must be a mapping.")
    task = config.get("task")
    if not isinstance(task, str) or not task.strip():
        raise ConfigValidationError("task must be a non-empty string.")
    for section in ("runtime", "run", "data", "metrics", "output", "clearml", "stage_inputs", "_meta"):
        value = config.get(section)
        if value is not None and not isinstance(value, Mapping):
            raise ConfigValidationError(f"{section} must be a mapping.")
    _validate_fields(config)
    seed = _get(config, "run.seed")
    if seed is not None:
        if isinstance(seed, bool) or not isinstance(seed, int):
            raise ConfigValidationError("run.seed must be an integer or null.")
        if not 0 <= seed < 2**32:
            raise ConfigValidationError("run.seed must be between 0 and 4294967295.")
    stage = _get(config, "run.stage")
    if stage is not None:
        try:
            as_stage_name(stage)
        except ValueError as exc:
            raise ConfigValidationError(str(exc)) from exc


def _validate_fields(config: Mapping[str, Any]) -> None:
    strings = (
        "profile",
        "runtime.output_dir",
        "run.name",
        "data.local_path",
        "data.clearml_dataset_id",
        "data.dataset_file",
        "data.source_manifest",
        "output.prediction_name",
    )
    for path in strings:
        value = _get(config, path)
        if value is not None and not isinstance(value, str):
            raise ConfigValidationError(f"{path} must be a string or null.")
    for path in ("runtime.use_clearml", "output.upload_plots"):
        value = _get(config, path)
        if value is not None and not isinstance(value, bool):
            raise ConfigValidationError(f"{path} must be a boolean or null.")
    names = _get(config, "metrics.names")
    if names is not None and not isinstance(names, (str, list, tuple)):
        raise ConfigValidationError("metrics.names must be a list, comma string, or null.")
    context = _get(config, "runtime.execution_context")
    if context is not None and not isinstance(context, Mapping):
        raise ConfigValidationError("runtime.execution_context must be a mapping or null.")


def _get(config: Mapping[str, Any], path: str) -> Any:
    value: Any = config
    for key in path.split("."):
        if not isinstance(value, Mapping) or key not in value:
            return None
        value = value[key]
    return value
