from __future__ import annotations

import hashlib
import importlib
import json
import os
from collections.abc import Generator, Mapping
from contextlib import contextmanager
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

import yaml

from .contracts import _merge_output_paths
from .io import write_json
from .paths import resolve_path_within, safe_path_component
from .result import RunResult

LATEST_POINTER_SCHEMA_VERSION = 2
_LATEST_POINTER_NAME = ".ml-platform-latest.json"


def utc_timestamp() -> str:
    return datetime.now(UTC).strftime("%Y%m%dT%H%M%SZ")


def prepare_run_dir(base_dir: str | Path, run_name: str | None = None) -> Path:
    base_dir = Path(base_dir).resolve()
    base_dir.mkdir(parents=True, exist_ok=True)
    run_component = safe_path_component(run_name, default="run")
    timestamp = utc_timestamp()
    suffix = 1
    run_dir = base_dir / f"{run_component}_{timestamp}"
    while True:
        try:
            run_dir.mkdir(exist_ok=False)
            return run_dir
        except FileExistsError:
            run_dir = base_dir / f"{run_component}_{timestamp}_{suffix}"
            suffix += 1


def update_latest(run_dir: str | Path, latest_dir: str | Path) -> None:
    """Atomically point ``latest_dir`` at one immutable sibling run directory."""
    run_dir = Path(run_dir).resolve()
    latest_dir = Path(latest_dir).absolute()
    latest_dir.parent.mkdir(parents=True, exist_ok=True)
    _validate_latest_paths(run_dir, latest_dir)

    with publication_lock(latest_dir):
        _replace_latest_pointer(run_dir, latest_dir)


def resolve_latest_dir(latest_dir: str | Path) -> Path:
    """Resolve a local ``latest_*`` pointer to its immutable run directory."""
    latest_dir = Path(latest_dir).absolute()
    pointer = latest_dir / _LATEST_POINTER_NAME
    if not _path_exists(pointer):
        if _path_exists(latest_dir):
            raise ValueError(f"Latest publication pointer not found: {pointer}")
        return latest_dir
    if pointer.is_symlink() or not pointer.is_file():
        raise ValueError(f"Latest pointer must be a regular file: {pointer}")
    try:
        payload = json.loads(pointer.read_text(encoding="utf-8"))
    except (OSError, UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise ValueError(f"Latest pointer is unreadable: {pointer}") from exc
    if not isinstance(payload, dict) or payload.get("schema_version") != LATEST_POINTER_SCHEMA_VERSION:
        raise ValueError(f"Unsupported latest pointer schema: {pointer}")
    run_name = payload.get("run")
    if not isinstance(run_name, str) or not run_name:
        raise ValueError(f"Latest pointer run must be a non-empty string: {pointer}")
    run_dir = resolve_path_within(
        latest_dir.parent,
        run_name,
        setting="latest run",
        root_description="the output directory",
        allow_nested=False,
    )
    if run_dir.is_symlink() or not run_dir.is_dir():
        raise FileNotFoundError(f"Latest run directory not found: {run_dir}")
    return run_dir


def is_latest_publication(path: str | Path) -> bool:
    """Return whether a directory contains a local latest-run pointer."""
    return _path_exists(Path(path).absolute() / _LATEST_POINTER_NAME)


def _validate_latest_paths(run_dir: Path, latest_dir: Path) -> None:
    if run_dir.is_symlink() or not run_dir.is_dir():
        raise ValueError(f"run_dir must be an existing regular directory: {run_dir}")
    resolved_latest = latest_dir.resolve()
    if run_dir == resolved_latest:
        raise ValueError("run_dir and latest_dir must be different paths.")
    if _is_relative_to(run_dir, resolved_latest) or _is_relative_to(resolved_latest, run_dir):
        raise ValueError("run_dir and latest_dir must not contain one another.")
    if run_dir.parent != latest_dir.parent.resolve():
        raise ValueError("run_dir and latest_dir must be siblings in the same output directory.")


def _is_relative_to(path: Path, root: Path) -> bool:
    try:
        path.relative_to(root)
        return True
    except ValueError:
        return False


def _replace_latest_pointer(run_dir: Path, latest_dir: Path) -> None:
    if _path_exists(latest_dir) and (latest_dir.is_symlink() or not latest_dir.is_dir()):
        raise ValueError("latest_dir must be a regular directory.")
    latest_dir.mkdir(parents=True, exist_ok=True)
    pointer = latest_dir / _LATEST_POINTER_NAME
    temp = latest_dir / f"{_LATEST_POINTER_NAME}.tmp"
    unexpected = [path for path in latest_dir.iterdir() if path not in {pointer, temp}]
    if unexpected:
        raise ValueError(f"Latest publication directory has no pointer: {latest_dir}")
    payload = {
        "schema_version": LATEST_POINTER_SCHEMA_VERSION,
        "run": run_dir.name,
    }
    try:
        with temp.open("w", encoding="utf-8", newline="\n") as handle:
            json.dump(payload, handle, ensure_ascii=False, indent=2)
            handle.write("\n")
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temp, pointer)
    finally:
        temp.unlink(missing_ok=True)


def _path_exists(path: Path) -> bool:
    return path.exists() or path.is_symlink()


@contextmanager
def publication_lock(latest_dir: Path) -> Generator[None, None, None]:
    lock_path = latest_dir.with_name(f".{latest_dir.name}.lock")
    with lock_path.open("a+b") as handle:
        handle.seek(0, os.SEEK_END)
        if handle.tell() == 0:
            handle.write(b"\0")
            handle.flush()
        handle.seek(0)
        if os.name == "nt":
            locking = importlib.import_module("msvcrt")
            locking.locking(handle.fileno(), locking.LK_LOCK, 1)
        else:
            locking = importlib.import_module("fcntl")
            locking.flock(handle.fileno(), locking.LOCK_EX)
        try:
            yield
        finally:
            handle.seek(0)
            if os.name == "nt":
                locking.locking(handle.fileno(), locking.LK_UNLCK, 1)
            else:
                locking.flock(handle.fileno(), locking.LOCK_UN)


def file_hash(path: str | Path) -> str:
    path = Path(path)
    digest = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def write_config_snapshot(config: dict[str, Any], run_dir: str | Path) -> Path:
    run_dir = Path(run_dir)
    path = run_dir / "config.yaml"
    path.write_text(yaml.safe_dump(config, allow_unicode=True, sort_keys=False), encoding="utf-8")
    return path


def _artifact_entry(path: str | Path, hashes: dict[str, str]) -> dict[str, Any]:
    p = Path(path)
    if not p.exists():
        raise FileNotFoundError(f"Manifest output does not exist: {p}")
    key = str(p.resolve())
    if p.is_file() and key not in hashes:
        hashes[key] = file_hash(p)
    return {
        "path": str(p),
        "sha256": hashes.get(key),
    }


def _artifact_entries(paths: Mapping[str, str | Path] | None, hashes: dict[str, str]) -> dict[str, dict[str, Any]]:
    return {name: _artifact_entry(path, hashes) for name, path in (paths or {}).items()}


def write_manifest(
    run_dir: str | Path,
    *,
    config: Mapping[str, Any],
    metrics: Mapping[str, Any] | None = None,
    artifacts: Mapping[str, str | Path] | None = None,
    tables: Mapping[str, str | Path] | None = None,
    plots: Mapping[str, str | Path] | None = None,
    extra: Mapping[str, Any] | None = None,
) -> Path:
    """Write a small manifest for reproducibility and handoff inspection."""
    run_dir = Path(run_dir)
    hashes: dict[str, str] = {}
    manifest = {
        "created_at": utc_timestamp(),
        "task": config.get("task"),
        "profile": config.get("profile"),
        "run_name": config.get("run", {}).get("name"),
        "run_dir": str(run_dir),
        "config_meta": config.get("_meta", {}),
        "metrics": metrics or {},
        "artifacts": _artifact_entries(artifacts, hashes),
        "tables": _artifact_entries(tables, hashes),
        "plots": _artifact_entries(plots, hashes),
        "extra": extra or {},
    }
    return write_json(manifest, run_dir / "manifest.json")


def finish_run(
    config: dict[str, Any],
    run_dir: str | Path,
    *,
    metrics: dict[str, Any] | None = None,
    artifacts: dict[str, Path] | None = None,
    tables: dict[str, Path] | None = None,
    plots: dict[str, Path] | None = None,
    extra: dict[str, Any] | None = None,
) -> RunResult:
    """Finish common snapshot/manifest/result bookkeeping, without publication."""
    root = Path(run_dir)
    root.mkdir(parents=True, exist_ok=True)
    outputs = {**(artifacts or {})}
    config_path, manifest_path = root / "config.yaml", root / "manifest.json"
    _merge_output_paths(outputs, tables or {}, plots or {}, {"config": config_path, "manifest": manifest_path})
    outputs.pop("manifest", None)
    if "config" not in outputs:
        outputs["config"] = write_config_snapshot(config, root)
    outputs["manifest"] = write_manifest(
        root,
        config=config,
        metrics=metrics,
        artifacts=outputs,
        tables=tables,
        plots=plots,
        extra=extra,
    )
    return RunResult(
        run_dir=root,
        metrics=dict(metrics or {}),
        artifacts=outputs,
        tables=dict(tables or {}),
        plots=dict(plots or {}),
        extra=dict(extra or {}),
    )
