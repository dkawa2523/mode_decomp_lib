"""Common stage identifier syntax; membership belongs to each manifest."""

from __future__ import annotations

import re
from typing import TypeAlias

StageName: TypeAlias = str


def as_stage_name(value: str) -> StageName:
    if not isinstance(value, str) or not re.fullmatch(r"[A-Za-z_][A-Za-z0-9_-]*", value):
        raise ValueError("run.stage must be a non-empty stage identifier or null.")
    return value
