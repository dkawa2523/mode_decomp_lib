from __future__ import annotations

import hashlib
import re
import unicodedata
from pathlib import Path

_INVALID_COMPONENT_CHARACTERS = re.compile(r'[<>:"/\\|?*\x00-\x1f]')
_WHITESPACE = re.compile(r"\s+")
_WINDOWS_RESERVED_NAMES = {
    "CON",
    "PRN",
    "AUX",
    "NUL",
    *(f"COM{index}" for index in range(1, 10)),
    *(f"LPT{index}" for index in range(1, 10)),
}


def ensure_path_within(
    root: str | Path,
    path: str | Path,
    *,
    setting: str,
    root_description: str,
) -> Path:
    """Resolve a path and require its final target to remain below ``root``."""
    resolved_root = Path(root).resolve()
    candidate = Path(path).resolve()
    try:
        candidate.relative_to(resolved_root)
    except ValueError as exc:
        raise ValueError(f"{setting} must stay within {root_description}.") from exc
    return candidate


def resolve_path_within(
    root: str | Path,
    relative_path: str | Path,
    *,
    setting: str,
    root_description: str,
    allow_nested: bool = True,
) -> Path:
    """Resolve a user-provided relative path without allowing root escape."""
    if not isinstance(relative_path, (str, Path)):
        raise ValueError(f"{setting} must be a relative path.")
    if isinstance(relative_path, str) and not relative_path.strip():
        raise ValueError(f"{setting} must be a non-empty relative path.")

    relative = Path(relative_path)
    if not relative.parts:
        raise ValueError(f"{setting} must be a non-empty relative path.")
    if not allow_nested and (relative.is_absolute() or relative.drive or len(relative.parts) != 1):
        raise ValueError(f"{setting} must be a single file name.")
    if relative.is_absolute() or relative.drive or ".." in relative.parts:
        raise ValueError(f"{setting} must stay within {root_description}.")

    resolved_root = Path(root).resolve()
    return ensure_path_within(
        resolved_root,
        resolved_root / relative,
        setting=setting,
        root_description=root_description,
    )


def safe_path_component(value: object, *, default: str = "run", max_length: int = 96) -> str:
    """Convert a display name to one portable, bounded filesystem component."""
    raw = unicodedata.normalize("NFKC", str(value or ""))
    sanitized = _INVALID_COMPONENT_CHARACTERS.sub("_", raw)
    sanitized = _WHITESPACE.sub("_", sanitized).strip(" ._") or default

    if sanitized.split(".", maxsplit=1)[0].upper() in _WINDOWS_RESERVED_NAMES:
        sanitized = f"_{sanitized}"
    if len(sanitized) <= max_length:
        return sanitized

    digest = hashlib.sha256(raw.encode("utf-8")).hexdigest()[:10]
    prefix_length = max(1, max_length - len(digest) - 1)
    return f"{sanitized[:prefix_length].rstrip(' ._')}_{digest}"
