"""Common model bytes/runtime/provenance checks before deserialization."""

from __future__ import annotations

import platform
from collections.abc import Iterable, Mapping
from importlib.metadata import PackageNotFoundError, version
from pathlib import Path
from typing import Any

from .artifacts import file_hash


def runtime_identity(packages: Iterable[str]) -> dict[str, Any]:
    installed = {}
    for package in sorted(set(packages)):
        try:
            installed[package] = version(package)
        except PackageNotFoundError:
            continue
    return {"python": platform.python_version(), "packages": installed}


def validate_model_integrity(
    path: str | Path,
    info: Mapping[str, Any],
    expected_context: Mapping[str, Any] | None = None,
) -> None:
    """Validate shared identities; callers validate their own schema versions."""
    validate_artifact_integrity(path, info, expected_context)
    _validate_runtime(info.get("runtime"))


def validate_artifact_integrity(
    path: str | Path,
    info: Mapping[str, Any],
    expected_context: Mapping[str, Any] | None = None,
) -> None:
    """Check bytes and requested provenance; the consumer owns backend compatibility.

    The existing validate_model_integrity entry point retains its strict runtime
    policy for callers which require that policy.
    """
    expected_hash = info.get("model_sha256")
    if not isinstance(expected_hash, str) or not expected_hash:
        raise ValueError("model_info.model_sha256 is required for this model artifact.")
    if file_hash(path) != expected_hash:
        raise ValueError("Model artifact hash does not match model_info.model_sha256.")
    _validate_provenance(info, expected_context or {})


def _validate_provenance(info: Mapping[str, Any], expected: Mapping[str, Any]) -> None:
    if expected.get("model_sha256") and expected["model_sha256"] != info.get("model_sha256"):
        raise ValueError("Resolved model hash disagrees with model_info.model_sha256.")
    source_release, execution_release = expected.get("source_release_id"), expected.get("execution_release_id")
    if source_release and execution_release and source_release != execution_release:
        raise ValueError("Inference execution release must match the model source release.")
    recorded = info.get("provenance") or {}
    if not isinstance(recorded, Mapping):
        raise ValueError("model_info.provenance must be a mapping.")
    for key in (
        "source_pipeline_task_id",
        "source_release_id",
        "source_revision",
        "source_diff_sha256",
        "requirements_sha256",
        "runtime_id",
    ):
        if expected.get(key) and recorded.get(key) != expected[key]:
            raise ValueError(f"Model provenance disagrees with the execution context: {key}.")


def _validate_runtime(runtime: Any) -> None:
    if not isinstance(runtime, Mapping) or not isinstance(runtime.get("packages"), Mapping):
        raise ValueError("model_info.runtime is required for this model artifact.")
    trained_python = str(runtime.get("python") or "")
    current_python = platform.python_version()
    if trained_python.split(".")[:2] != current_python.split(".")[:2]:
        raise ValueError(f"Model requires Python {trained_python}; current runtime is {current_python}.")
    for package, trained_version in runtime["packages"].items():
        try:
            current_version = version(str(package))
        except PackageNotFoundError as exc:
            raise ValueError(f"Model requires package {package}=={trained_version}, but it is not installed.") from exc
        if current_version != trained_version:
            raise ValueError(
                f"Model requires package {package}=={trained_version}; current runtime has {current_version}."
            )
