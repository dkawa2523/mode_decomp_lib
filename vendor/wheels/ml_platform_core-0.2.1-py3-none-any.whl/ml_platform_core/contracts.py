"""Small manifest records shared by the product and ClearML adapter."""

from __future__ import annotations

from collections.abc import Mapping
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Literal, TypeVar

from .result import RunResult

ParameterValueType = Literal["str", "int", "float", "bool", "list", "dict", "enum", "json"]


@dataclass(frozen=True)
class ParameterSpec:
    name: str
    value_type: ParameterValueType
    config_path: tuple[str, ...] = field(default_factory=tuple)
    description: str = ""
    public: bool = True


@dataclass(frozen=True)
class StageSpec:
    key: str
    parameters: tuple[ParameterSpec, ...] = field(default_factory=tuple)
    output_artifacts: tuple[str, ...] = field(default_factory=tuple)


@dataclass(frozen=True)
class TaskSpec:
    key: str
    parameters: tuple[ParameterSpec, ...] = field(default_factory=tuple)


_Spec = TypeVar("_Spec", StageSpec, TaskSpec)


@dataclass(frozen=True)
class PackageManifest:
    tasks: tuple[TaskSpec, ...]
    stages: tuple[StageSpec, ...]

    def stage(self, key: str) -> StageSpec:
        return _lookup(self.stages, key, "stage")

    def task(self, key: str) -> TaskSpec:
        return _lookup(self.tasks, key, "task")


def _lookup(items: tuple[_Spec, ...], key: str, kind: str) -> _Spec:
    for item in items:
        if item.key == key:
            return item
    raise KeyError(f"Unknown {kind}: {key}")


@dataclass(frozen=True)
class DomainStepPlan:
    name: str
    stage_key: str
    parents: tuple[str, ...] = field(default_factory=tuple)
    parameter_overrides: dict[str, object] = field(default_factory=dict)
    expected_artifacts: tuple[str, ...] = field(default_factory=tuple)
    model_name: str | None = None


@dataclass(frozen=True)
class ArtifactRef:
    """An output key on a successful predecessor, independent of transport."""

    step_name: str
    artifact_name: str

    def __post_init__(self) -> None:
        for value in (self.step_name, self.artifact_name):
            if not isinstance(value, str) or not value.strip():
                raise ValueError("ArtifactRef names must be non-empty strings.")


def _merge_output_paths(*groups: Mapping[str, str | Path]) -> dict[str, Path]:
    paths: dict[str, Path] = {}
    for group in groups:
        for key, value in group.items():
            path = Path(value)
            if key in paths and paths[key].resolve() != path.resolve():
                raise ValueError(f"Output key {key!r} refers to different paths.")
            paths[key] = path
    return paths


def resolve_artifact_refs(value: Any, results: Mapping[str, RunResult]) -> Any:
    """Resolve references in dict/list/tuple values without mutating inputs."""
    if isinstance(value, ArtifactRef):
        result = results[value.step_name]
        outputs = _merge_output_paths(result.artifacts, result.tables, result.plots)
        return outputs[value.artifact_name]
    if isinstance(value, dict):
        return {key: resolve_artifact_refs(item, results) for key, item in value.items()}
    if isinstance(value, list):
        return [resolve_artifact_refs(item, results) for item in value]
    if isinstance(value, tuple):
        return tuple(resolve_artifact_refs(item, results) for item in value)
    return value
